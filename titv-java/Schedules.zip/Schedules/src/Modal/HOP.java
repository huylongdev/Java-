package Modal;

import java.util.Date;

public class HOP {
	private String ID_HOP;
	private String NOI_DUNG;
	private Date NGAY_DANGKI;
	private Date GIO_DANGKI;
	private Byte ID_DANGKI;
	private Date NGAY_HOP;
	private Date START_GIOHOP;
	private Date STOP_GIOHOP;
	private Byte ID_DIADIEM;
	
	public HOP(String ID_HOP,String NOI_DUNG,Date NGAY_DANGKI, Date GIO_DANGKI,Byte ID_DANGKI,Date NGAY_HOP,Date START_GIOHOP,Date STOP_GIOHOP,Byte ID_DIADIEM) {
		this.ID_HOP = ID_HOP;
		this.NOI_DUNG = NOI_DUNG;
		this.NGAY_DANGKI = NGAY_DANGKI;
		this.GIO_DANGKI = GIO_DANGKI;
		this.ID_DANGKI = ID_DANGKI;
		this.NGAY_HOP = NGAY_HOP;
		this.START_GIOHOP = START_GIOHOP;
		this.STOP_GIOHOP = STOP_GIOHOP;
		this.ID_DIADIEM = ID_DIADIEM;
		
	}

	public String getID_HOP() {
		return ID_HOP;
	}

	public void setID_HOP(String iD_HOP) {
		ID_HOP = iD_HOP;
	}

	public String getNOI_DUNG() {
		return NOI_DUNG;
	}

	public void setNOI_DUNG(String nOI_DUNG) {
		NOI_DUNG = nOI_DUNG;
	}

	public Date getNGAY_DANGKI() {
		return NGAY_DANGKI;
	}

	public void setNGAY_DANGKI(Date nGAY_DANGKI) {
		NGAY_DANGKI = nGAY_DANGKI;
	}

	public Date getGIO_DANGKI() {
		return GIO_DANGKI;
	}

	public void setGIO_DANGKI(Date gIO_DANGKI) {
		GIO_DANGKI = gIO_DANGKI;
	}

	public Byte getID_DANGKI() {
		return ID_DANGKI;
	}

	public void setID_DANGKI(Byte iD_DANGKI) {
		ID_DANGKI = iD_DANGKI;
	}

	public Date getNGAY_HOP() {
		return NGAY_HOP;
	}

	public void setNGAY_HOP(Date nGAY_HOP) {
		NGAY_HOP = nGAY_HOP;
	}

	public Date getSTART_GIOHOP() {
		return START_GIOHOP;
	}

	public void setSTART_GIOHOP(Date sTART_GIOHOP) {
		START_GIOHOP = sTART_GIOHOP;
	}

	public Date getSTOP_GIOHOP() {
		return STOP_GIOHOP;
	}

	public void setSTOP_GIOHOP(Date sTOP_GIOHOP) {
		STOP_GIOHOP = sTOP_GIOHOP;
	}

	public Byte getID_DIADIEM() {
		return ID_DIADIEM;
	}
	public void setID_DIADIEM(Byte iD_DIADIEM) {
		ID_DIADIEM = iD_DIADIEM;
	}

	@Override
	public String toString() {
		return "HOP [ID_HOP=" + ID_HOP + ", NOI_DUNG=" + NOI_DUNG + ", NGAY_DANGKI=" + NGAY_DANGKI + ", GIO_DANGKI="
				+ GIO_DANGKI + ", ID_DANGKI=" + ID_DANGKI + ", NGAY_HOP=" + NGAY_HOP + ", START_GIOHOP=" + START_GIOHOP
				+ ", STOP_GIOHOP=" + STOP_GIOHOP + ", ID_DIADIEM=" + ID_DIADIEM + "]";
	}

}
