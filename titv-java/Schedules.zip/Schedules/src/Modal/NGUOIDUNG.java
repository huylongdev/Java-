package Modal;

public class NGUOIDUNG {
	private String ID_NGUOIDUNG;
	private String ID_NHANSU;
	private String USERNAME;
	private String PASSWORD;
	private String LEVER_USER;
	
	public NGUOIDUNG (String ID_NGUOIDUNG,String ID_NHANSU, String USERNAME,String PASSWORD,
			 String LEVER_USER) {
			this.ID_NGUOIDUNG = ID_NGUOIDUNG;
			this.ID_NHANSU = ID_NHANSU;
			this.USERNAME = USERNAME;
			this.PASSWORD = PASSWORD;
			this.LEVER_USER = LEVER_USER;
	}



	public void setID_NGUOIDUNG(String iD_NGUOIDUNG) {
		ID_NGUOIDUNG = iD_NGUOIDUNG;
	}

	public String getID_NHANSU() {
		return ID_NHANSU;
	}

	public void setID_NHANSU(String iD_NHANSU) {
		ID_NHANSU = iD_NHANSU;
	}

	public String getUSERNAME() {
		return USERNAME;
	}

	public void setUSERNAME(String uSERNAME) {
		USERNAME = uSERNAME;
	}

	public String getPASSWORD() {
		return PASSWORD;
	}

	public void setPASSWORD(String pASSWORD) {
		PASSWORD = pASSWORD;
	}

	public String getLEVER_USER() {
		return LEVER_USER;
	}

	public void setLEVER_USER(String lEVER_USER) {
		LEVER_USER = lEVER_USER;
	}

	public Object getID_NGUOIDUNG() {
		return null;
	}
	
	
}
