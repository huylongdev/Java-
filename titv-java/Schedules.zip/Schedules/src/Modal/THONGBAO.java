package Modal;

public class THONGBAO {
	private String ID_THONGBAO;
	private String ID_NGUOITB;
	private String ID_NGUOIDUOCTB;
	public THONGBAO(String ID_THONGBAO,String ID_NGUOITB,String ID_NGUOIDUOCTB) {
		this.ID_THONGBAO = ID_THONGBAO;
		this.ID_NGUOITB = ID_NGUOITB;
		this.ID_NGUOIDUOCTB = ID_NGUOIDUOCTB;
	}
	public String getID_THONGBAO() {
		return ID_THONGBAO;
	}
	public void setID_THONGBAO(String iD_THONGBAO) {
		ID_THONGBAO = iD_THONGBAO;
	}
	public String getID_NGUOITB() {
		return ID_NGUOITB;
	}
	public void setID_NGUOITB(String iD_NGUOITB) {
		ID_NGUOITB = iD_NGUOITB;
	}
	public String getID_NGUOIDUOCTB() {
		return ID_NGUOIDUOCTB;
	}
	public void setID_NGUOIDUOCTB(String iD_NGUOIDUOCTB) {
		ID_NGUOIDUOCTB = iD_NGUOIDUOCTB;
	}
	
}
