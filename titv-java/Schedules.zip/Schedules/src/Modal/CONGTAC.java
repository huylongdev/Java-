package Modal;
import java.util.Date;


public class CONGTAC {
	
	private String ID_NHANSU;
	private String NOI_DUNG;
	private Date START_NGAYCONGTAC;
	private Date STOP_NGAYCONGTAC;
	private String NOI_CONGTAC;
	private String PHUONG_TIEN;
	private String ID_DANGKI;
	private Date NGAY_DANGKI;
	


	public CONGTAC(String ID_NHANSU, String NOI_DUNG,Date START_NGAYCONGTAC,Date STOP_NGAYCONGTAC,
String NOI_CONGTAC,String PHUONG_TIEN,String ID_DANGKI,	Date NGAY_DANGKI) {
		this.ID_NHANSU = ID_NHANSU;
		this.NOI_DUNG = NOI_DUNG;
		this.START_NGAYCONGTAC = START_NGAYCONGTAC;
		this.STOP_NGAYCONGTAC = STOP_NGAYCONGTAC;
		this.NOI_CONGTAC = NOI_CONGTAC;
		this.PHUONG_TIEN = PHUONG_TIEN;
		this.ID_DANGKI = ID_DANGKI;
		this.NGAY_DANGKI = NGAY_DANGKI;
	}
	
	public String getID_NHANSU() {
		return ID_NHANSU;
	}

	public void setID_NHANSU(String iD_NHANSU) {
		ID_NHANSU = iD_NHANSU;
	}

	public String getNOI_DUNG() {
		return NOI_DUNG;
	}

	public void setNOI_DUNG(String nOI_DUNG) {
		NOI_DUNG = nOI_DUNG;
	}

	public Date getSTART_NGAYCONGTAC() {
		return START_NGAYCONGTAC;
	}

	public void setSTART_NGAYCONGTAC(Date sTART_NGAYCONGTAC) {
		START_NGAYCONGTAC = sTART_NGAYCONGTAC;
	}

	public Date getSTOP_NGAYCONGTAC() {
		return STOP_NGAYCONGTAC;
	}

	public void setSTOP_NGAYCONGTAC(Date sTOP_NGAYCONGTAC) {
		STOP_NGAYCONGTAC = sTOP_NGAYCONGTAC;
	}

	public String getNOI_CONGTAC() {
		return NOI_CONGTAC;
	}

	public void setNOI_CONGTAC(String nOI_CONGTAC) {
		NOI_CONGTAC = nOI_CONGTAC;
	}

	public String getPHUONG_TIEN() {
		return PHUONG_TIEN;
	}

	public void setPHUONG_TIEN(String pHUONG_TIEN) {
		PHUONG_TIEN = pHUONG_TIEN;
	}

	public String getID_DANGKI() {
		return ID_DANGKI;
	}

	public void setID_DANGKI(String iD_DANGKI) {
		ID_DANGKI = iD_DANGKI;
	}

	public Date getNGAY_DANGKI() {
		return NGAY_DANGKI;
	}

	public void setNGAY_DANGKI(Date nGAY_DANGKI) {
		NGAY_DANGKI = nGAY_DANGKI;
	}

	@Override
	public String toString() {
		return "CONGTAC [ID_NHANSU=" + ID_NHANSU + ", NOI_DUNG=" + NOI_DUNG + ", START_NGAYCONGTAC=" + START_NGAYCONGTAC
				+ ", STOP_NGAYCONGTAC=" + STOP_NGAYCONGTAC + ", NOI_CONGTAC=" + NOI_CONGTAC + ", PHUONG_TIEN="
				+ PHUONG_TIEN + ", ID_DANGKI=" + ID_DANGKI + ", NGAY_DANGKI=" + NGAY_DANGKI + "]";
	}
}
