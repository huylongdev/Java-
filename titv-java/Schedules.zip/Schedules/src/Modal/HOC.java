package Modal;
import java.util.Date;
public class HOC {
	String ID_HOC;
	String ID_NHANSU;
	String NOI_DUNG;
	Date START_NGAYHOC;
	Date STOP_NGAYHOC;
	Date START_GIOHOC;
	String NOI_HOC;
	String ID_DANGKI;
	Date NGAY_DANGKI;
	Date STOP_GIOHOC;
	public HOC(String ID_HOC,String ID_NHANSU,String NOI_DUNG,Date START_NGAYHOC,Date STOP_NGAYHOC,Date START_GIOHOC,String NOI_HOC,
			String ID_DANGKI,Date NGAY_DANGKI, Date STOP_GIOHOC) {
		this.ID_HOC = ID_HOC;
		this.ID_NHANSU = ID_NHANSU;
		this.NOI_DUNG = NOI_DUNG;
		this.START_NGAYHOC = START_NGAYHOC;
		this.STOP_NGAYHOC = STOP_NGAYHOC;
		this.START_GIOHOC = START_GIOHOC;
		this.NOI_HOC = NOI_HOC;
		this.ID_DANGKI = ID_DANGKI;
		this.NGAY_DANGKI = NGAY_DANGKI;
		this.STOP_GIOHOC = STOP_GIOHOC;
	}
	public String getID_HOC() {
		return ID_HOC;
	}
	public void setID_HOC(String iD_HOC) {
		ID_HOC = iD_HOC;
	}
	public String getID_NHANSU() {
		return ID_NHANSU;
	}
	public void setID_NHANSU(String iD_NHANSU) {
		ID_NHANSU = iD_NHANSU;
	}
	public String getNOI_DUNG() {
		return NOI_DUNG;
	}
	public void setNOI_DUNG(String nOI_DUNG) {
		NOI_DUNG = nOI_DUNG;
	}
	public Date getSTART_NGAYHOC() {
		return START_NGAYHOC;
	}
	public void setSTART_NGAYHOC(Date sTART_NGAYHOC) {
		START_NGAYHOC = sTART_NGAYHOC;
	}
	public Date getSTOP_NGAYHOC() {
		return STOP_NGAYHOC;
	}
	public void setSTOP_NGAYHOC(Date sTOP_NGAYHOC) {
		STOP_NGAYHOC = sTOP_NGAYHOC;
	}
	public Date getSTART_GIOHOC() {
		return START_GIOHOC;
	}
	public void setSTART_GIOHOC(Date sTART_GIOHOC) {
		START_GIOHOC = sTART_GIOHOC;
	}
	public String getNOI_HOC() {
		return NOI_HOC;
	}
	public void setNOI_HOC(String nOI_HOC) {
		NOI_HOC = nOI_HOC;
	}
	public String getID_DANGKI() {
		return ID_DANGKI;
	}
	public void setID_DANGKI(String iD_DANGKI) {
		ID_DANGKI = iD_DANGKI;
	}
	public Date getNGAY_DANGKI() {
		return NGAY_DANGKI;
	}
	public void setNGAY_DANGKI(Date nGAY_DANGKI) {
		NGAY_DANGKI = nGAY_DANGKI;
	}
	public Date getSTOP_GIOHOC() {
		return STOP_GIOHOC;
	}

	public void setSTOP_GIOHOC(Date sTOP_GIOHOC) {
		STOP_GIOHOC = sTOP_GIOHOC;
	}
	@Override
	public String toString() {
		return "HOC [ID_HOC=" + ID_HOC + ", ID_NHANSU=" + ID_NHANSU + ", NOI_DUNG=" + NOI_DUNG + ", START_NGAYHOC="
				+ START_NGAYHOC + ", STOP_NGAYHOC=" + STOP_NGAYHOC + ", START_GIOHOC=" + START_GIOHOC + ", NOI_HOC="
				+ NOI_HOC + ", ID_DANGKI=" + ID_DANGKI + ", NGAY_DANGKI=" + NGAY_DANGKI + ", STOP_GIOHOC=" + STOP_GIOHOC
				+ "]";
	}
}
