package Modal;
import java.util.Date;
import java.util.Scanner;

public class PHEP {
	 private String ID_PHEP;
	 private String ID_NHANSU;
	 private String NOI_DUNG;
	 private String ID_DANGKI;
	 private Date NGAY_DANGKI;
	 private Date START_NGAYPHEP;
	 private Date STOP_NGAYPHEP;
	 private int BOUND;
	 private String NOI_NGHI; 

	public PHEP(String ID_PHEP, String ID_NHANSU, String NOI_DUNG, String ID_DANGKI, Date NGAY_DANGKI,Date START_NGAYPHEP, Date STOP_NGAYPHEP, int BOUND, String NOI_NGHI ) {
        this.ID_PHEP = ID_PHEP;
        this.ID_NHANSU = ID_NHANSU;
        this.NOI_DUNG =  NOI_DUNG;
        this.ID_DANGKI = ID_DANGKI;
        this.NGAY_DANGKI = NGAY_DANGKI;
        this.START_NGAYPHEP = START_NGAYPHEP;
        this.STOP_NGAYPHEP = STOP_NGAYPHEP;
        this.BOUND = BOUND;
        this.NOI_NGHI = NOI_NGHI;    
    }

	public String getID_PHEP() {
		return ID_PHEP;
	}


	public void setID_PHEP(String iD_PHEP) {
		ID_PHEP = iD_PHEP;
	}

	public String getID_NHANSU() {
		return ID_NHANSU;
	}

	public void setID_NHANSU(String iD_NHANSU) {
		ID_NHANSU = iD_NHANSU;
	}

	public String getNOI_DUNG() {
		return NOI_DUNG;
	}

	public void setNOI_DUNG(String nOI_DUNG) {
		NOI_DUNG = nOI_DUNG;
	}

	public String getID_DANGKI() {
		return ID_DANGKI;
	}

	public void setID_DANGKI(String iD_DANGKI) {
		ID_DANGKI = iD_DANGKI;
	}

	public Date getNGAY_DANGKI() {
		return NGAY_DANGKI;
	}

	public void setNGAY_DANGKI(Date nGAY_DANGKI) {
		NGAY_DANGKI = nGAY_DANGKI;
	}

	public Date getSTART_NGAYPHEP() {
		return START_NGAYPHEP;
	}

	public void setSTART_NGAYPHEP(Date sTART_NGAYPHEP) {
		START_NGAYPHEP = sTART_NGAYPHEP;
	}

	public Date getSTOP_NGAYPHEP() {
		return STOP_NGAYPHEP;
	}

	public void setSTOP_NGAYPHEP(Date sTOP_NGAYPHEP) {
		STOP_NGAYPHEP = sTOP_NGAYPHEP;
	}

	public int getBOUND() {
		return BOUND;
	}

	public void setBOUND(int bOUND) {
		BOUND = bOUND;
	}

	public String getNOI_NGHI() {
		return NOI_NGHI;
	}

	public void setNOI_NGHI(String nOI_NGHI) {
		NOI_NGHI = nOI_NGHI;
	}
	
	@Override
	public String toString() {
		return "PHEP [ID_PHEP=" + ID_PHEP + ", ID_NHANSU=" + ID_NHANSU + ", NOI_DUNG=" + NOI_DUNG + ", ID_DANGKI="
				+ ID_DANGKI + ", NGAY_DANGKI=" + NGAY_DANGKI + ", START_NGAYPHEP=" + START_NGAYPHEP + ", STOP_NGAYPHEP="
				+ STOP_NGAYPHEP + ", BOUND=" + BOUND + ", NOI_NGHI=" + NOI_NGHI + ", getID_PHEP()=" + getID_PHEP()
				+ ", getID_NHANSU()=" + getID_NHANSU() + ", getNOI_DUNG()=" + getNOI_DUNG() + ", getID_DANGKI()="
				+ getID_DANGKI() + ", getNGAY_DANGKI()=" + getNGAY_DANGKI() + ", getSTART_NGAYPHEP()="
				+ getSTART_NGAYPHEP() + ", getSTOP_NGAYPHEP()=" + getSTOP_NGAYPHEP() + ", getBOUND()=" + getBOUND()
				+ ", getNOI_NGHI()=" + getNOI_NGHI() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}	

}
