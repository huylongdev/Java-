package Controller;

import java.util.ArrayList;
import java.util.List;

import Modal.NGUOIDUNG;
public class NHANSU {	
	protected String ID_NHANSU;
	protected String ID_PHONG;
	protected String TEN_NHANSU;
	
	


    private List<NGUOIDUNG> users;

    public NHANSU() {
        this.users = new ArrayList<>();
    }

    public void addUser(NGUOIDUNG user) {
        this.users.add(user);
    }

    public void removeUserByID(String userID) {
        NGUOIDUNG userToRemove = null;
        for (NGUOIDUNG user : this.users) {
            if (user.getID_NGUOIDUNG().equals(userID)) {
                userToRemove = user;
                break;
            }
        }
        if (userToRemove != null) {
            this.users.remove(userToRemove);
        } else {
            System.out.println("User with ID " + userID + " not found.");
        }
    }

    public void updateUser(String userID, NGUOIDUNG updatedUser) {
        for (int i = 0; i < this.users.size(); i++) {
            NGUOIDUNG user = this.users.get(i);
            if (user.getID_NGUOIDUNG().equals(userID)) {
                this.users.set(i, updatedUser);
                System.out.println("User with ID " + userID + " updated successfully.");
                return;
            }
        }
        System.out.println("User with ID " + userID + " not found.");
    }
    private List<Schedule> schedules;

    public ScheduleManager() {
        this.schedules = new ArrayList<>();
    }

    public boolean registerSchedule(Schedule newSchedule) {
        for (Schedule existingSchedule : schedules) {
            if (existingSchedule.overlapsWith(newSchedule)) {
                System.out.println("Warning: The new schedule overlaps with an existing schedule.");
                return false;
            }
        }
        schedules.add(newSchedule);
        System.out.println("Schedule registered successfully.");
        return true;
    }
}
